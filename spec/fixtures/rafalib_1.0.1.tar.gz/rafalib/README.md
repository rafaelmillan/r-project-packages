# installation

```
library(devtools) # get from CRAN with install.packages("devtools")
install_github("ririzarr/rafalib")
```

# example images

* imagesort() https://twitter.com/mikelove/status/525683889273331712/photo/1
* imagemat() https://twitter.com/mikelove/status/525644674447704064/photo/1
* shist() https://twitter.com/mikelove/status/524974079590563840/photo/1
* sboxplot() https://twitter.com/mikelove/status/524226701249626112/photo/1
* splot() https://twitter.com/mikelove/status/523157013136543744/photo/1
